import Order from "../models/Order.js";
import OrderItem from "../models/OrderItem.js";
import Product from "../models/Product.js";
import User from "../models/User.js";
import { sequelize } from "../config/connectDB.js";
import sendOrderEmail from "../utils/sendOrderEmail.js";

// ── Helper: standard include for OrderItems ───────────────────────────────────
const withItems = { include: [{ model: OrderItem, as: "orderItems" }] };

export const createOrder = async (req, res) => {
  const t = await sequelize.transaction();
  try {
    const {
      items, shippingAddress, paymentMethod, paymentResult,
      itemsPrice, shippingPrice, gstAmount, totalPrice, isPaid, paidAt,
    } = req.body;

    if (!items || !items.length) {
      await t.rollback();
      return res.status(400).json({ message: "No order items", error: true, success: false });
    }

    // ── 1. Secure Price Validation & Stock Reduction ────────────────────────
    let secureItemsPrice = 0;

    for (const item of items) {
      const productId = item.product || item.productId;
      const qty = item.qty || item.quantity || 1;

      const product = await Product.findByPk(productId, { transaction: t, lock: t.LOCK.UPDATE });
      if (!product) {
        await t.rollback();
        return res.status(400).json({ message: `Product ${productId} not found`, error: true, success: false });
      }
      if (product.countInStock < qty) {
        await t.rollback();
        return res.status(400).json({
          message: `Insufficient stock for "${product.name}". Only ${product.countInStock} left.`,
          error: true, success: false,
        });
      }
      secureItemsPrice += (product.price * qty);

      await product.update({ countInStock: product.countInStock - qty }, { transaction: t });
    }

    // Mathematical integrity check to prevent payload manipulation attacks
    if (Number(shippingPrice) < 0 || Number(gstAmount) < 0) {
      await t.rollback();
      return res.status(400).json({ message: "Invalid price modifiers.", error: true, success: false });
    }

    const backendExpectedTotal = secureItemsPrice + Number(gstAmount || 0) + Number(shippingPrice || 0);

    // Hard Security Rejection: If the paid price is less than half the total cost of the physical products, reject unless they gave a valid code.
    // (You can expand this logic later to verify explicit DB-verified Coupons).
    if (Number(totalPrice) < (backendExpectedTotal * 0.55)) {
      console.error(`[SECURITY ALERT] Order rejected for User ${req.userId}! Price manipulation detected. Expected ~${backendExpectedTotal}, got ${totalPrice}`);
      await t.rollback();
      return res.status(400).json({
        message: "Payment validation failed: The total amount does not match the product value.",
        error: true,
        success: false
      });
    }

    // ── 2. Create Order row ───────────────────────────────────────────────────
    const order = await Order.create(
      {
        userId: req.userId,
        items,
        shippingAddress: shippingAddress || {},
        paymentMethod: paymentMethod || "COD",
        paymentResult: paymentResult || {},
        itemsPrice: secureItemsPrice,     // USE SECURE DB PRICE
        shippingPrice: shippingPrice || 0,
        gstAmount: gstAmount || 0,
        totalPrice: totalPrice || 0,
        isPaid: isPaid === true,
        paidAt: isPaid ? (paidAt || new Date()) : null,
      },
      { transaction: t }
    );

    // ── 3. Bulk-create OrderItems ─────────────────────────────────────────────
    const orderItemsData = items.map((item) => ({
      orderId: order.id,
      productId: item.product || item.productId || null,
      name: item.name || "",
      image: item.image || "",
      price: item.price || 0,
      qty: item.qty || item.quantity || 1,
    }));
    await OrderItem.bulkCreate(orderItemsData, { transaction: t });

    await t.commit();

    // ── 4. Reload with OrderItems, then send email (fire-and-forget) ──────────
    const fullOrder = await Order.findByPk(order.id, withItems);

    User.findByPk(req.userId)
      .then((user) => sendOrderEmail(fullOrder, user))
      .catch((err) => console.error("[EMAIL ERROR]", err.message));

    return res.status(201).json({ order: fullOrder, message: "Order created successfully", success: true, error: false });
  } catch (error) {
    await t.rollback();
    return res.status(500).json({ message: "Internal server error", error: true, success: false });
  }
};

export const getUserOrders = async (req, res) => {
  try {
    const orders = await Order.findAll({
      where: { userId: req.userId },
      order: [["createdAt", "DESC"]],
      ...withItems,
    });
    return res.status(200).json({ orders, message: "Orders fetched successfully", success: true, error: false });
  } catch (error) {
    return res.status(500).json({ message: "Internal server error", error: true, success: false });
  }
};

export const getOrderById = async (req, res) => {
  try {
    const order = await Order.findByPk(req.params.id, withItems);
    if (!order) {
      return res.status(404).json({ message: "Order not found", error: true, success: false });
    }

    // Only owner or admin can view
    if (order.userId !== req.userId) {
      const user = await User.findByPk(req.userId);
      if (!user || user.role !== "admin") {
        return res.status(403).json({ message: "Access denied", error: true, success: false });
      }
    }

    return res.status(200).json({ order, message: "Order fetched successfully", success: true, error: false });
  } catch (error) {
    return res.status(500).json({ message: "Internal server error", error: true, success: false });
  }
};

export const getAllOrders = async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const perPage = parseInt(req.query.perPage) || 10;
    const totalOrders = await Order.count();
    const totalPages = Math.ceil(totalOrders / perPage);

    const orders = await Order.findAll({
      order: [["createdAt", "DESC"]],
      offset: (page - 1) * perPage,
      limit: perPage,
      ...withItems,
    });

    return res.status(200).json({ orders, totalPages, page, totalOrders, message: "All orders fetched", success: true, error: false });
  } catch (error) {
    return res.status(500).json({ message: "Internal server error", error: true, success: false });
  }
};

export const updateOrderStatus = async (req, res) => {
  try {
    const { status } = req.body;
    const validStatuses = ["pending", "processing", "shipped", "delivered", "cancelled"];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({ message: "Invalid status value", error: true, success: false });
    }

    const order = await Order.findByPk(req.params.id);
    if (!order) {
      return res.status(404).json({ message: "Order not found", error: true, success: false });
    }

    order.status = status;
    await order.save();

    return res.status(200).json({ order, message: "Order status updated", success: true, error: false });
  } catch (error) {
    return res.status(500).json({ message: "Internal server error", error: true, success: false });
  }
};
