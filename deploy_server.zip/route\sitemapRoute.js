import { Router } from "express";
import Product from "../models/Product.js";

const sitemapRouter = Router();

sitemapRouter.get("/sitemap.xml", async (req, res) => {
    try {
        const products = await Product.findAll({
            attributes: ['id', 'updatedAt'],
            limit: 5000 // SEO standard limit per simple page
        });

        const frontendUrl = process.env.FRONTEND_URL || "http://localhost:5173";

        let xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>${frontendUrl}/</loc>
    <changefreq>daily</changefreq>
    <priority>1.0</priority>
  </url>
  <url>
    <loc>${frontendUrl}/productListing</loc>
    <changefreq>daily</changefreq>
    <priority>0.8</priority>
  </url>`;

        products.forEach((product) => {
            xml += `
  <url>
    <loc>${frontendUrl}/product/${product.id}</loc>
    <lastmod>${new Date(product.updatedAt).toISOString()}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.6</priority>
  </url>`;
        });

        xml += `\n</urlset>`;

        res.header("Content-Type", "application/xml");
        res.status(200).send(xml);
    } catch (error) {
        console.error("[SITEMAP ERROR]", error);
        res.status(500).end();
    }
});

export default sitemapRouter;
